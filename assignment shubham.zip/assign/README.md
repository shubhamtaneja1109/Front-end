### LIVE DEMO :- <a href="https://responsivebar.ccbp.tech/">Responsive Nav Bar</a>
# navbar-responsive-website-1
A responsive website which is developed using  bootstrap. Navbar changes based on screen width

### Refer to the below images.</br>

The following images illustrate all device sizes, from extra small to extra large.</br>

Extra Small (Size < 576px), Small (Size >= 576px) and Medium (Size >= 768px):</br></br>
** https://nkb-backend-media-static-tenxiitian.s3.ap-south-1.amazonaws.com/tenxiitian_prod/programs/Tech+Programs/frontend-content/ccbp/coding-practice-questions/responsive-website/vr-nav-and-banner-xs-v1.png</br></br>
** https://nkb-backend-media-static-tenxiitian.s3.ap-south-1.amazonaws.com/tenxiitian_prod/programs/Tech+Programs/frontend-content/ccbp/coding-practice-questions/responsive-website/vr-nav-expand-and-banner-xs-v1.png</br></br>
** https://nkb-backend-media-static-tenxiitian.s3.ap-south-1.amazonaws.com/tenxiitian_prod/programs/Tech+Programs/frontend-content/ccbp/coding-practice-questions/responsive-website/vr-nav-and-banner-lg-v1.png</br></br>


### Resources</br>
### Use the image URLs given below.</br>

### VR Logo: 
https://d1tgh8fmlzexmh.cloudfront.net/ccbp-responsive-website/vr-logo-img.png</br>

### Background Image: 
https://d1tgh8fmlzexmh.cloudfront.net/ccbp-responsive-website/vr-banner-bg.png</br>
